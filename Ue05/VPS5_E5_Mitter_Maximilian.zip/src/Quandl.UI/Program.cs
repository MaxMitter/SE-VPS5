﻿using System;
using System.Windows.Forms;

namespace Quandl.UI {
  static class Program {
    [STAThread]
    static void Main() {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new QuandlViewer());
    }
  }
}
